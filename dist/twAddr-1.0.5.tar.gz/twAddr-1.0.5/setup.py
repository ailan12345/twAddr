from distutils.core import setup
import sys
import twaddr.addrdata
from setuptools.command.install import install


class twAddr_install(install):
    def run(self):
        print('Building Addr ... ')
        sys.stdout.flush()
        twAddr.addrdata.createDB()
        install.run(self)

setup(
    name = 'twAddr',
    packages = ['twaddr'],
    #scripts = ['runner'],
    version = '1.0.5',
    description = 'Taiwan address related services',
    author = 'Ailan',
    author_email = 'karta2599434@gmail.com',
    keywords = ['tw', 'addr'],
    classifiers = [],
    url = 'https://github.com/ailan12345/twAddr',

    package_data = {'zipcode': ['*.csv']},
    cmdclass = {'install': twAddr_install},
)
