 台灣地址服務
========
- 地址翻譯
- 3+2 郵遞區號查詢
- 3+3 郵遞區號查詢 (明年1月)


安裝
------------

    $ pip install twAddr
    $ python -m twaddr.addrdata
    
使用
------------

    開發中
